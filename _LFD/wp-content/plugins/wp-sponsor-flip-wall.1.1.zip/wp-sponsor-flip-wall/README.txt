=== WP Sponsor Flip Wall ===

Contributors: Samuel Ramon

Tags: sponsor, flip, wall, jquery, plugin

Requires at least: 3.1.2

Donate link: http://phpcafe.com.br/donate

Tested up to: 3.2.1

Stable tag: 1.1



This is a WordPress plugin that use jquery's sponsor flip wall plugin. This provide an administration to include, alter and deletes sponsors.



== Description ==



This plugin provides yous a simple sponsors administration. You can include, alter and delete the sponsors.

To use ir you only need to put the render code wherever you want to show the soponsor flip wall:

	1. Put the function <?php wp_sfw_render(); ?> where you want to show the sponsor flip wall;

	2. Make sure you have using the jQuery Framework;

	3. In case of errors, send the information about it to me



This is my first wordpress plugin to the community. I hope it help someone =D.
section
Here some interesting links that I used to make the plugin:

<a href="http://lab.smashup.it/flip/"> Flip! A jquery plugin </a>

<a href="http://tutorialzine.com/2010/03/sponsor-wall-flip-jquery-css/"> Sponsor Flip Wall With jQuery & CSS </a>



== Installation ==



1. Download the file to the folder '/wp-content/plugins/';

2. Active the plugin in WordPress Plugins interface;

3. Configure the plugin defaults;

4. Call the Sponsor Flip Wall with calling the function <?php wp_sfw_render() ?> where you wanto to show it.


== Frequently Asked Questions ==

None

== Changelog ==

1.1 - Included the functionality to add the wp_sponsor_flip_wall to a post

1.0 - First Commit

== Upgrade Notice ==

None

== Screenshots ==

1. The plugin menu
2. The plugin configuration
3. The list sponso's view
4. The include page
5. The edit page
6. This is how your page looks like
